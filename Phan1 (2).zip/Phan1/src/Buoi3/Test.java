package Buoi3;

import java.util.ArrayList;
import java.util.Scanner;

public class Test {
	public static void main(String[] args) {
		try {
			QuanLy ql = new QuanLy();
			ArrayList ds = ql.getThongTin("dulieu.txt");
			ql.HienThiNV(ds);
			ql.HienThiSV(ds);
			
			Scanner oj = new Scanner(System.in);
			String key = oj.nextLine();
			SinhVien b = ql.HienThi(ds, key);
			System.out.println(b);
			ql.luuFile(ds);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	
	
	
}
