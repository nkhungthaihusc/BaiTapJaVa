
public class Test {
	public static void main(String[] args) {
		BtFile bt = new BtFile();
		try {
			bt.TaoDanhSach(5);
			bt.XuatDanhSach();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
