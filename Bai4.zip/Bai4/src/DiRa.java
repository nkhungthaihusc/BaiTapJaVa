
public class DiRa {
	int LoaiXe;
	String BienSoXe;
	String SoVeXe;
	String ThoiGianRa;
	String TinhTrangXe;
	public int getLoaiXe() {
		return LoaiXe;
	}
	public void setLoaiXe(int loaiXe) {
		LoaiXe = loaiXe;
	}
	public String getBienSoXe() {
		return BienSoXe;
	}
	public void setBienSoXe(String bienSoXe) {
		BienSoXe = bienSoXe;
	}
	public String getSoVeXe() {
		return SoVeXe;
	}
	public void setSoVeXe(String soVeXe) {
		SoVeXe = soVeXe;
	}
	public String getThoiGianRa() {
		return ThoiGianRa;
	}
	public void setThoiGianRa(String thoiGianRa) {
		ThoiGianRa = thoiGianRa;
	}
	public String getTinhTrangXe() {
		return TinhTrangXe;
	}
	public void setTinhTrangXe(String tinhTrangXe) {
		TinhTrangXe = tinhTrangXe;
	}
	@Override
	public String toString() {
		return "DiRa [LoaiXe=" + LoaiXe + ", BienSoXe=" + BienSoXe + ", SoVeXe=" + SoVeXe + ", ThoiGianRa=" + ThoiGianRa
				+ ", TinhTrangXe=" + TinhTrangXe + "]";
	}
	
	
}
