
public class DiVao {
	int LoaiXe;
	String BienSoXe;
	String SoVeXe;
	String ThoiGianVao;
	String TinhTrangXe;
	public int getLoaiXe() {
		return LoaiXe;
	}
	public void setLoaiXe(int loaiXe) {
		LoaiXe = loaiXe;
	}
	public String getBienSoXe() {
		return BienSoXe;
	}
	public void setBienSoXe(String bienSoXe) {
		BienSoXe = bienSoXe;
	}
	public String getSoVeXe() {
		return SoVeXe;
	}
	public void setSoVeXe(String soVeXe) {
		SoVeXe = soVeXe;
	}
	public String getThoiGianVao() {
		return ThoiGianVao;
	}
	public void setThoiGianVao(String thoiGianVao) {
		ThoiGianVao = thoiGianVao;
	}
	public String getTinhTrangXe() {
		return TinhTrangXe;
	}
	public void setTinhTrangXe(String tinhTrangXe) {
		TinhTrangXe = tinhTrangXe;
	}
	@Override
	public String toString() {
		return "DiVao [LoaiXe=" + LoaiXe + ", BienSoXe=" + BienSoXe + ", SoVeXe=" + SoVeXe + ", ThoiGianVao="
				+ ThoiGianVao + ", TinhTrangXe=" + TinhTrangXe + "]";
	}
	
}
