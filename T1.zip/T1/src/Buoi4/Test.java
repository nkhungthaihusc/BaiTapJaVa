package Buoi4;

import java.util.ArrayList;
import java.util.Scanner;

public class Test {
	public static void main(String[] args) {
		long a = (long) Math.ceil(1441 / (60 * 24.0));
		System.out.println(a);
	}
	
	
	
	
}
