/**
 * 
 */
/**
 * 
 */
module T1 {
	requires java.desktop;
}