package Y1;

public class t {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("test");

	}

}
